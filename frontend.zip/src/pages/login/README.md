# Login

The Login page renders a login form with email/password by default and a remember me checkbox.
