# Signup

The Signup page renders a signup form with email/password by default and an optional username field.
